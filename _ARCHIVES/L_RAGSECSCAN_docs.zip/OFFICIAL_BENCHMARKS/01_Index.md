# Official Benchmarks

**Project:** `L_RAGSECSCAN`  
**Tier:** TIER_6_SECURITY_EVAL  
**Identity:** Upstream `protectai/llm-guard` @ `168c1034ffdb` (MIT)

## Collected results

Corpus benchmark record: `E:\fenta\Downloads\The Anticloud\BENCHMARKS\BENCHMARK_RESULTS.md`.

## What belongs in this folder

- Published or third-party results, quoted as-is with the source.
- OSINT findings, each carrying its source and date.
- OWASP findings, each carrying the test and its version.
- PAX results 1 and 2, frozen: recorded, never re-run or edited.

## Not fabricated

No figure appears here unless it was read from an artifact. A benchmark
slot with nothing in it is a stated gap, because a plausible-looking
number in this folder is indistinguishable from a measured one to any
later reader.
